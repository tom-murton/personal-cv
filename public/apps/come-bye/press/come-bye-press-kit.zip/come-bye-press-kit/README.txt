Come Bye: A Sheepdog Year, press kit
https://tommurton.com/apps/come-bye/press/

Developer: Tom Murton (solo, United Kingdom)
Release date: 8 December 2026
Platform: iPhone (portrait, one hand)
Price: free download; the first spring is free; one purchase (GBP 4.99 / USD 4.99) opens the rest of the year.
No ads, no subscription. English.
App Store: https://apps.apple.com/app/id6811601275
Press contact: hello@weevolve.app

Everything here is real play from the game, with the game's own music. You are welcome to use it in coverage of Come Bye.
